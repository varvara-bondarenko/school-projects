Team Members: 
- Ariah Brittman
- Haley Pittman 
- Varvara Bondarenko


**To run the program:**
```
python3 main.py --input [filename] -- debug (optional)
```

The input files must be located in the testing/ folder within the project for the program to run. 
An optional flag to the program is `--debug` (doesn't take any arguments), which prints more information to the CLI, used for debugging. 


The final program has time complexity higher than claimed during project phase 2, because we decided to add another traversal over the jobs to collect information related to scheduling.